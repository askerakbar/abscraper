var Crawler = require("crawler");
var url = require('url');
var fs = require('fs');
const siteUrl = 'https://www.alibaba.com/';
const log = require('node-file-logger');
const mysql = require('mysql');
const options = require('./config.js');
logOtptions = options.logOtptions;
dbOptions = options.dbOptions;
log.SetUserOptions(logOtptions); 
const con = mysql.createConnection(dbOptions);
var Crawler = require("crawler");




var c = new Crawler({
    maxConnections : 10,
    // This will be called for each crawled page
    callback : function (error, res, done) {
        if(error){
            
        }else{
            console.log(res);
        }
        done();
    }
});

c.on('schedule',function(options){
    proxyUrl = 'https://gimmeproxy.com/api/getProxy';

    options.proxy = "http://140.190.54.187:53277";
/*     asyncoptions.proxy = async function(){
         request(proxyUrl, function (error, response, html) {
            console.log(response);
            return response;
        });     
    } */
});


c.queue("https://api.ipify.org/?format=json");